# hugging-rag
High-Level Library for RAG task with Huggingface API
